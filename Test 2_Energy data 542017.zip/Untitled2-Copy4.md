
###### Objective- The objective of this analysis is to develop a ARIMA model for energy demand forecasting. The model shall predict demand having data of the daily demand the days before. 

I have used Python programming (Jupyter notebook). Data source and python code is provided within this document to ensure fully reproducible research.

Data link- C:\Users\Amit\Dropbox\Dataset\Energydata_spain.csv

Data Description-Data file captures daily energy demand in Spain(in GWh) between 2004 and 2012. 

###### 2.	Plot out your time series variable(s) separately.  Tell me using your Mark I eyeball whether or not you think the time series data set is stationary in terms of constant mean and also constant variance.


```python
# load dataset using read_csv()
from pandas import read_csv
series = read_csv('Energydata_spain.csv', header=0, parse_dates=[0], index_col=0, squeeze=True)
print(type(series))
print(series.head())
```

    <class 'pandas.core.series.Series'>
    Date
    2004-01-01    488.07
    2004-01-02    582.02
    2004-01-03    575.58
    2004-01-04    542.39
    2004-01-05    600.26
    Name: demand, dtype: float64
    


```python
# calculate descriptive statistics
from pandas import Series
series = Series.from_csv('Energydata_spain.csv', header=0)
print(series.describe())
```

    count    3288.000000
    mean      692.738932
    std        80.534059
    min       459.430000
    25%       640.727500
    50%       698.395000
    75%       747.752500
    max       901.870000
    Name: demand, dtype: float64
    

 The describe() function creates a seven number summary of the loaded time series including mean, standard deviation, median,minimum,and maximum of the observations. Descriptive statistics helps get an idea of the distribution and spread of values. This may help with ideas of data scaling and even data cleaning that we can perform later as part  of preparing our dataset for modeling.


```python
from matplotlib import pyplot
series.plot()
pyplot.show()
```


![png](output_6_0.png)


Since the graph is very dense, I tried to make it less dense using same line plot with dots instead of the connected line.


```python
series.plot(style='k--.')
pyplot.show()
```


![png](output_8_0.png)


Though It looks like the series has a constant mean and variance, It is not clearly evident that there is an overall increasing trend in the data along with some seasonal variations. So, more formally, we can check stationarity using the Dickey-Fuller Test

###### 3.	Plot the ACF for each time series data set. Looking at ACF, does it look like there may be a trend or non-constant mean for each time series?

Before plotting ACF I have done some descriptive statistics Plots(Histogram, KDE, boxplot and heatmap) to understand data better


```python
series.hist()
pyplot.show()
```


![png](output_12_0.png)



```python
series.plot(kind='kde')
pyplot.show()
```


![png](output_13_0.png)


Histogram shows a distribution that looks strongly Gaussian. The plotting function automatically selects the 
size of the bins based on the spread of values in the data. Using KDE, we observe that perhaps the distribution is a little asymmetrical and perhaps a little pointy to be Guassian


```python
X = series.values
train_size = int(len(X) * 0.50)
train, test = X[0:train_size], X[train_size:len(X)]
print('Observations: %d' % (len(X)))
print('Training Observations: %d' % (len(train)))
print('Testing Observations: %d' % (len(test)))
pyplot.plot(train)
pyplot.plot([None for i in train] + [x for x in test])
pyplot.show()
```

    Observations: 3288
    Training Observations: 1644
    Testing Observations: 1644
    


![png](output_15_1.png)



```python
# calculate and plot monthly average
from pandas import Series
from matplotlib import pyplot
# create a boxplot of monthly data
from pandas import Series
from pandas import DataFrame
from pandas import TimeGrouper
from matplotlib import pyplot
from pandas import concat
resample = series.resample('M')
monthly_mean = resample.mean()
print(monthly_mean.head())
monthly_mean.plot()
pyplot.show()
```

    Date
    2004-01-31    645.243548
    2004-02-29    664.466552
    2004-03-31    655.299032
    2004-04-30    593.891333
    2004-05-31    592.023226
    Freq: M, Name: demand, dtype: float64
    


![png](output_16_1.png)



```python
# create a boxplot of monthly data
from pandas import Series
from pandas import DataFrame
from pandas import TimeGrouper
from matplotlib import pyplot
from pandas import concat
one_year = series['2012']
groups = one_year.groupby(TimeGrouper('M'))
months = concat([DataFrame(x[1].values) for x in groups], axis=1)
months = DataFrame(months)
months.columns = range(1,13)
months.boxplot()
pyplot.show()
```


![png](output_17_0.png)



```python
# create a heat map of monthly data
from pandas import Series
from pandas import DataFrame
from pandas import TimeGrouper
from matplotlib import pyplot
from pandas import concat
one_year = series['2012']
groups = one_year.groupby(TimeGrouper('M'))
months = concat([DataFrame(x[1].values) for x in groups], axis=1)
months = DataFrame(months)
months.columns = range(1,13)
pyplot.matshow(months, interpolation=None, aspect='auto')
pyplot.show()
```


![png](output_18_0.png)



```python
### ACF plot for each time series data set. 
```

We would expect the ACF for the AR(k) time series to be strong to a lag of k and the inertia of that relationship would carry on to subsequent lag values, trailing off at some point as the effect was weakened


```python

from pandas.tools.plotting import autocorrelation_plot
autocorrelation_plot(series)
pyplot.show()
```


![png](output_21_0.png)


ACF captures the relationship of an observation with past observations in the same and opposite seasons or times of year. Sine waves like this seen in this example are a strong sign of seasonality in the dataset.


```python
# autocorrelation plot of time series 
from pandas import Series
from matplotlib import pyplot
from statsmodels.graphics.tsaplots import plot_acf
plot_acf(series, lags=31)
pyplot.show()
```


![png](output_23_0.png)


The autocorrelation function shows a highly autocorrelated seasonal non-stationary process with, as expected, yearly and weekly cicles. The ACF alone, however, tells us little about the orders of dependence for ARMA or AR processes

###### 4.	Now let’s examine each time series data set using unit root tests.   First use the KPSS test for each time series data set and tell me if the test suggests if there is a constant mean or not.  Then see if you can confirm your KPSS evaluation using the Augmented Dickey Fuller test for each time series.  Tell me what you find for each data set.

Kwiatkowski-Philips-Schmidt-Shin (KPSS) test Here accepting null hypothesis means that the series is stationary, and small p-value suggest that the series is NOT stationary and a differencing may be required
###### KPSS output using R

I have used R for KPSS test as it is not available in Python

Code and output for kpss test

kpss_test1 <- kpss.test(df[ ,2], null="Level")
kpss_test1

KPSS Test for Level Stationarity

data:  df[, 2]
KPSS Level = 1.9367, Truncation lag parameter = 13, p-value = 0.01

> kpss_test2 <- kpss.test(df[ ,2], null="Trend")

Warning message:
In kpss.test(df[, 2], null = "Trend") :
  p-value smaller than printed p-value
> kpss_test2

	KPSS Test for Trend Stationarity

data:  df[, 2]
KPSS Trend = 0.80825, Truncation lag parameter = 13, p-value = 0.01

### Augemented Dickey Fuller Test

The Augmented Dickey-Fuller test is the most common unit root test used. It is a regression of the first difference of the variable on its lagged level as well as additional lags of the first difference. The null is that the series contains a unit root, and the alternative is that the series is stationary.

By default, the number of lags is selected by minimizing the AIC across a range of lag lengths (which can be set using max_lag when initializing the model). Additionally, the basic test includes a constant in the ADF regression.


```python
from statsmodels.tsa.stattools import adfuller
X = series.values
result = adfuller(X)
print('Results of Dickey-Fuller Test:')
print('ADF Statistic: %f' % result[0])
print('p-value: %f' % result[1])
print('Critical Values:')
for key, value in result[4].items():
    print('\t%s: %.3f' % (key, value))
```

    Results of Dickey-Fuller Test:
    ADF Statistic: -5.941666
    p-value: 0.000000
    Critical Values:
    	1%: -3.432
    	5%: -2.862
    	10%: -2.567
    

Running the Dickey- fuller test gives the test statistic value of -5.9 The more negative this statistic, the more likely we are to reject the null hypothesis (we have a stationary dataset). As part of the output, I get a look-up table to help determine the ADF statistic ( statistic value of -5.9 is less than the value of -3.4 at 1%. This suggests that we can reject the null hypothesis with a signifcance level of less than 1%(i.e. a low probability that the result is a statistical fluke). Rejecting the null hypothesis means that the process has no unit root, and in turn that the time series is stationary or does not have time-dependent structure.

Since based on the above results, we reject unit root(ADF), reject stationarity(KPSS): both hypothesis are component hypothesis – heteroskedasticity in series may make a big difference; if there is structural break it may  affect inference.


```python

```

#### PACF


```python
from statsmodels.graphics.tsaplots import plot_pacf
plot_pacf(series, lags=500)
pyplot.show()
```


![png](output_34_0.png)


PACF only describes the direct relationship between an observation and its lag. This would suggest that there would be no correlation for lag values beyond k.


```python
from statsmodels.graphics.tsaplots import plot_pacf
plot_pacf(series, lags=50)
pyplot.show()
```


![png](output_36_0.png)


PCAF graphs also indicates seasonality.The PACF is better for AR models, and also shows the weekly and yearly seasons, although the correlation is lost faster with the lag.

###### 5.	Review the decisions in step # 4.  If the test suggests that there is a non-constant mean then use differencing to create a new differenced variable for that time series data set.  

a.	Plot out the data for the new differenced data set(s).  Tell me if it looks like the differencing got rid of the trend or non-constant mean.
b.	Plot the ACF for the differenced time serie(s). Tell me if this new ACF plot looks like there now is no trend.

Use of differencing - Three different approaches


```python
# deseasonalize a time series using differencing
from pandas import Series
from matplotlib import pyplot
X = series.values
diff = list()
days_in_year = 366
for i in range(days_in_year, len(X)):
    value = X[i] - X[i - days_in_year]
    diff.append(value)
print(diff[:10])
pyplot.plot(diff)
pyplot.show()
```

    [47.729999999999961, -13.819999999999936, 143.20999999999992, 203.59000000000003, 129.10000000000002, 61.159999999999968, -13.050000000000068, -58.950000000000045, -73.430000000000064, 178.98000000000002]
    


![png](output_40_1.png)



```python
# deseasonalize a time series using month-based differencing
from pandas import Series
from matplotlib import pyplot
X = series.values
diff = list()
days_in_year = 365
for i in range(days_in_year, len(X)):
	month_str = str(series.index[i].year)+'-'+str(series.index[i].month)
	month_mean_last_year = series[month_str].mean()
	value = X[i] - month_mean_last_year
	diff.append(value)
# calculate and plot monthly average
print(diff[:10])
pyplot.plot(diff)
pyplot.show()
```

    [-55.054193548387161, -189.61967741935496, -157.21967741935487, -6.6296774193549481, 20.560322580645106, 3.9403225806451019, -119.49967741935495, -42.889677419354939, -65.489677419354962, -99.759677419354944]
    


![png](output_41_1.png)



```python
# deseasonalize by differencing with a polynomial model
from pandas import Series
from matplotlib import pyplot
from numpy import polyfit
# fit polynomial: x^2*b1 + x*b2 + ... + bn
X = [i%365 for i in range(0, len(series))]
y = series.values
degree = 4
coef = polyfit(X, y, degree)
# create curve
curve = list()
for i in range(len(X)):
    value = coef[-1]
    for d in range(degree):
        value += X[i]**(degree-d) * coef[d]
    curve.append(value)
# create seasonally adjusted
values = series.values
diff = list()
for i in range(len(values)):
    value = values[i] - curve[i]
    diff.append(value)
pyplot.plot(diff)
pyplot.show()
```


![png](output_42_0.png)


Yes, based on differencing plot we observe that series has constant mean and variance as compared to without differencing

Dickey-Fuller Test-This is one of the statistical tests for checking stationarity. Here the null hypothesis is that the TS is non-stationary. The test results comprise of a Test Statistic and some Critical Values for difference confidence levels. If the ‘Test Statistic’ is less than the ‘Critical Value’, we can reject the null hypothesis and say that the series is stationary.


```python
from statsmodels.tsa.stattools import adfuller
X = diff
result = adfuller(X)
print('Results of Dickey-Fuller Test:')
print('ADF Statistic: %f' % result[0])
print('p-value: %f' % result[1])
print('Critical Values:')
for key, value in result[4].items():
    print('\t%s: %.3f' % (key, value))
```

    Results of Dickey-Fuller Test:
    ADF Statistic: -7.015824
    p-value: 0.000000
    Critical Values:
    	1%: -3.432
    	5%: -2.862
    	10%: -2.567
    

Running the Dickey- fuller test gives the test statistic value of -7.0 The more negative this statistic, the more likely we are to reject the null hypothesis (we have a stationary dataset). As part of the output, I get a look-up table to help determine the ADF statistic ( statistic value of -7.0 is  less than the value of -3.4 at 1%. This suggests that we can reject the null hypothesis with a signifcance  level of less than 1%(i.e. a low probability that the result is a statistical  fluke). Rejecting the null hypothesis means that the process has no unit root, and in turn that the time series is stationary or does not have time-dependent structure.


```python
from pandas.tools.plotting import autocorrelation_plot
autocorrelation_plot(diff)
pyplot.show()

# autocorrelation plot of time series
from pandas import Series
from matplotlib import pyplot
from statsmodels.graphics.tsaplots import plot_acf
plot_acf(diff, lags=300)
pyplot.show()
```


![png](output_47_0.png)



![png](output_47_1.png)



```python
from statsmodels.graphics.tsaplots import plot_pacf
plot_pacf(diff, lags=50)
pyplot.show()
```


![png](output_48_0.png)


Differencing does help to make the series more stationary but does not help with seasonality 


```python
X = series.values
train_size = int(len(X) * 0.50)
train = X[0:train_size]
test=X[train_size:len(X)]
print('Observations: %d' % (len(X)))
print('Training Observations: %d' % (len(train)))
print('Testing Observations: %d' % (len(test)))
pyplot.plot(train)
pyplot.plot([None for i in train] + [x for x in test])
pyplot.show()
```

    Observations: 3288
    Training Observations: 1644
    Testing Observations: 1644
    


![png](output_50_1.png)


An econometric term used for observed time series. ARCH models are used to model financial time series with time varying volatility, such as stock price

--- FINAL VALUES: 
loglikelihood = -4441.63088090 (steplength = 6.4e-005)
Parameters:       8.6186     0.46756     0.58997
Gradients:  -9.9170e-008-8.4956e-007-5.6512e-007 (norm 7.27e-004)

theta[0]:        694.087 (1.61111)
theta[1]:        3032.46 (136.765)
theta[2]:       0.589967 (0.0392431)


Function evaluations: 50
Evaluations of gradient: 13

Model 1: GARCH, using observations 2004-01-03:2013-01-02 (T = 3288)
Dependent variable: demand
Standard errors based on Hessian

             coefficient   std. error      z       p-value 
  ---------------------------------------------------------
  const       694.087        1.61111     430.8    0.0000    ***

  alpha(0)   3032.46       136.765        22.17   6.28e-109 ***
  alpha(1)      0.589967     0.0392431    15.03   4.42e-051 ***

Mean dependent var   692.7389   S.D. dependent var   80.53406
Log-likelihood      −18871.61   Akaike criterion     37751.22
Schwarz criterion    37775.61   Hannan-Quinn         37759.96

Unconditional error variance = 7395.65
Likelihood ratio test for (G)ARCH terms:
  Chi-square(1) = 446.678 [3.81159e-099]


from arch import arch_model
am = arch_model(diff)
res = am.fit()

An econometric term used for observed time series. ARCH models are used to model financial time series with time-varying volatility, such as stock prices. 

###### PACF Plot the PACF for each of the time series data sets.  Using the combined information from the ACFs you plotted earlier along with the information in the PACFs, tell me for each of the time series data sets if you see autoregressive and/or moving average processes in them.  


```python
from statsmodels.graphics.tsaplots import plot_pacf
plot_pacf(series, lags=500)
pyplot.show()
```


![png](output_56_0.png)



```python
# AutoRegressive Integrated Moving Average.
# fit an ARIMA model and plot residual errors
from pandas import read_csv
from pandas import datetime
from pandas import DataFrame
from statsmodels.tsa.arima_model import ARIMA
from matplotlib import pyplot
# load dataset

# fit model
model = ARIMA(series, order=(6,1,2))
model_fit = model.fit(disp=0)
# summary of fit model
print(model_fit.summary())
# line plot of residuals
residuals = DataFrame(model_fit.resid)
residuals.plot()
pyplot.show()
# density plot of residuals
residuals.plot(kind='kde')
pyplot.show()
# summary stats of residuals
print(residuals.describe())
```

                                 ARIMA Model Results                              
    ==============================================================================
    Dep. Variable:               D.demand   No. Observations:                 3287
    Model:                 ARIMA(6, 1, 2)   Log Likelihood              -16292.425
    Method:                       css-mle   S.D. of innovations             34.350
    Date:                Thu, 04 May 2017   AIC                          32604.849
    Time:                        12:12:40   BIC                          32665.827
    Sample:                    01-02-2004   HQIC                         32626.681
                             - 12-31-2012                                         
    ==================================================================================
                         coef    std err          z      P>|z|      [95.0% Conf. Int.]
    ----------------------------------------------------------------------------------
    const              0.0209      0.193      0.108      0.914        -0.358     0.400
    ar.L1.D.demand    -0.9384      0.013    -71.111      0.000        -0.964    -0.913
    ar.L2.D.demand    -0.9251      0.013    -71.562      0.000        -0.950    -0.900
    ar.L3.D.demand    -0.8503      0.014    -60.219      0.000        -0.878    -0.823
    ar.L4.D.demand    -0.8496      0.014    -61.625      0.000        -0.877    -0.823
    ar.L5.D.demand    -0.8520      0.012    -71.001      0.000        -0.875    -0.828
    ar.L6.D.demand    -0.8248      0.010    -81.351      0.000        -0.845    -0.805
    ma.L1.D.demand     0.7218      0.023     30.950      0.000         0.676     0.767
    ma.L2.D.demand     0.2912      0.017     17.066      0.000         0.258     0.325
                                        Roots                                    
    =============================================================================
                     Real           Imaginary           Modulus         Frequency
    -----------------------------------------------------------------------------
    AR.1            0.6513           -0.7989j            1.0307           -0.1411
    AR.2            0.6513           +0.7989j            1.0307            0.1411
    AR.3           -0.9341           -0.4625j            1.0423           -0.4268
    AR.4           -0.9341           +0.4625j            1.0423            0.4268
    AR.5           -0.2336           -0.9979j            1.0249           -0.2866
    AR.6           -0.2336           +0.9979j            1.0249            0.2866
    MA.1           -1.2395           -1.3778j            1.8533           -0.3666
    MA.2           -1.2395           +1.3778j            1.8533            0.3666
    -----------------------------------------------------------------------------
    


![png](output_57_1.png)



![png](output_57_2.png)


                     0
    count  3287.000000
    mean      0.055160
    std      34.516566
    min    -180.478779
    25%     -16.242909
    50%      -1.916759
    75%      15.168925
    max     233.986402
    

The above code gives a summary of the the model. This summarizes the coefficient values used as well as the skill of the fit on the on the in-sample observations.

ARIMA(5,1,0)
AIC                          34884.701
BIC                          34927.385
HQIC                         34899.983

ARIMA(6,1,2)(Best Model as AIC,BIC and HQIC are lowest 

AIC                          32604.849
BIC                          32665.827
HQIC                         32626.681


Line plot of the residual errors, suggesting that there may still be some trend information not captured by the model.
Density plot of the residual error values, suggesting the errors are Gaussian and centered on zero.

The distribution of the residual errors is displayed. The results show that indeed there is not
bias in the prediction (a close to zero mean in the residuals).

#### Forecast ARIMA Model


```python
# evaluate an ARIMA model using a walk-forward validation
from pandas import read_csv
from pandas import datetime
from matplotlib import pyplot
from statsmodels.tsa.arima_model import ARIMA
from sklearn.metrics import mean_squared_error
from math import sqrt
X = series.values
size = int(len(X) * 0.875)
train, test = X[0:size], X[size:len(X)]
history = [x for x in train]
predictions = list()
# walk-forward validation
for t in range(len(test)):
    model = ARIMA(history, order=(5,1,0))
    model_fit = model.fit(disp=0)
    output = model_fit.forecast()
    yhat = output[0]
    predictions.append(yhat)
    obs = test[t]
    history.append(obs)
    print('predicted=%f, expected=%f' % (yhat, obs))
# evaluate forecasts
rmse = sqrt(mean_squared_error(test, predictions))
print('Test RMSE: %.3f' % rmse)
# plot forecasts against actual outcomes
pyplot.plot(test)
pyplot.plot(predictions, color='red')
pyplot.show()
```

    predicted=719.766852, expected=722.070000
    predicted=701.933160, expected=721.000000
    predicted=638.258368, expected=644.620000
    predicted=655.774364, expected=587.840000
    predicted=642.058716, expected=714.360000
    predicted=743.663675, expected=730.180000
    predicted=706.498519, expected=719.270000
    predicted=725.095074, expected=727.030000
    predicted=715.086659, expected=721.000000
    predicted=644.591353, expected=640.250000
    predicted=653.766445, expected=598.240000
    predicted=658.503538, expected=740.000000
    predicted=760.858408, expected=754.620000
    predicted=721.161774, expected=761.330000
    predicted=755.140209, expected=755.450000
    predicted=723.845101, expected=746.270000
    predicted=662.550849, expected=670.000000
    predicted=684.532322, expected=611.110000
    predicted=668.542721, expected=702.410000
    predicted=751.284279, expected=646.360000
    predicted=664.084280, expected=707.790000
    predicted=751.257799, expected=638.300000
    predicted=646.862107, expected=705.280000
    predicted=669.136100, expected=671.200000
    predicted=682.526690, expected=637.780000
    predicted=625.104672, expected=758.160000
    predicted=779.914298, expected=767.500000
    predicted=686.025596, expected=761.060000
    predicted=739.703045, expected=760.100000
    predicted=738.943836, expected=762.870000
    predicted=693.327802, expected=675.840000
    predicted=691.911425, expected=642.840000
    predicted=701.216101, expected=779.370000
    predicted=800.855932, expected=791.940000
    predicted=755.463361, expected=762.800000
    predicted=768.720331, expected=748.310000
    predicted=735.771110, expected=726.180000
    predicted=668.623933, expected=615.850000
    predicted=662.214466, expected=547.260000
    predicted=654.209159, expected=640.730000
    predicted=717.226141, expected=713.660000
    predicted=723.317088, expected=714.290000
    predicted=722.988953, expected=706.340000
    predicted=686.474727, expected=695.840000
    predicted=624.328112, expected=628.410000
    predicted=610.968487, expected=553.160000
    predicted=614.078173, expected=673.500000
    predicted=722.455055, expected=735.240000
    predicted=714.320376, expected=748.880000
    predicted=727.425268, expected=723.200000
    predicted=699.636204, expected=604.100000
    predicted=550.317144, expected=644.040000
    predicted=670.615841, expected=634.190000
    predicted=663.765026, expected=771.050000
    predicted=783.492181, expected=804.520000
    predicted=780.924417, expected=814.170000
    predicted=718.614538, expected=819.110000
    predicted=758.969300, expected=816.790000
    predicted=721.279472, expected=724.790000
    predicted=723.112269, expected=680.060000
    predicted=734.623792, expected=818.690000
    predicted=846.572925, expected=817.630000
    predicted=792.622450, expected=815.650000
    predicted=828.693422, expected=808.810000
    predicted=791.207377, expected=787.270000
    predicted=717.923478, expected=699.290000
    predicted=735.696482, expected=647.100000
    predicted=719.571167, expected=772.150000
    predicted=818.822206, expected=787.100000
    predicted=778.504610, expected=797.020000
    predicted=804.216576, expected=802.110000
    predicted=777.582853, expected=798.080000
    predicted=715.714791, expected=711.220000
    predicted=719.758030, expected=656.780000
    predicted=711.256607, expected=793.340000
    predicted=825.398146, expected=820.030000
    predicted=792.904920, expected=822.630000
    predicted=820.567199, expected=845.250000
    predicted=813.369278, expected=852.870000
    predicted=750.635496, expected=779.890000
    predicted=767.523114, expected=727.660000
    predicted=767.699705, expected=826.390000
    predicted=846.430693, expected=832.590000
    predicted=818.683635, expected=859.050000
    predicted=869.340174, expected=864.900000
    predicted=843.662114, expected=848.390000
    predicted=779.883716, expected=753.050000
    predicted=769.574935, expected=710.190000
    predicted=761.989401, expected=854.710000
    predicted=885.869735, expected=860.340000
    predicted=839.092079, expected=841.430000
    predicted=853.672310, expected=831.350000
    predicted=818.047631, expected=816.400000
    predicted=748.495302, expected=728.100000
    predicted=764.181934, expected=663.330000
    predicted=747.078748, expected=786.340000
    predicted=840.212410, expected=803.010000
    predicted=796.528150, expected=807.080000
    predicted=819.953972, expected=795.580000
    predicted=785.353953, expected=772.590000
    predicted=706.598274, expected=688.070000
    predicted=714.119766, expected=624.600000
    predicted=696.467597, expected=731.990000
    predicted=790.694909, expected=733.950000
    predicted=742.196142, expected=740.000000
    predicted=764.125284, expected=743.180000
    predicted=738.883172, expected=750.000000
    predicted=682.149678, expected=662.520000
    predicted=674.732456, expected=610.500000
    predicted=663.192838, expected=723.770000
    predicted=757.548745, expected=753.000000
    predicted=730.939168, expected=758.340000
    predicted=763.169228, expected=756.220000
    predicted=733.951408, expected=744.500000
    predicted=671.562549, expected=661.340000
    predicted=669.414789, expected=605.020000
    predicted=666.037329, expected=710.900000
    predicted=756.290417, expected=723.590000
    predicted=720.328627, expected=712.330000
    predicted=731.989992, expected=715.920000
    predicted=713.056078, expected=712.160000
    predicted=650.732452, expected=639.030000
    predicted=653.166184, expected=586.390000
    predicted=645.450156, expected=657.000000
    predicted=698.451429, expected=748.070000
    predicted=736.605375, expected=766.420000
    predicted=743.604396, expected=745.440000
    predicted=710.040267, expected=729.610000
    predicted=666.354918, expected=645.720000
    predicted=623.872095, expected=554.130000
    predicted=624.136656, expected=691.220000
    predicted=761.335257, expected=704.420000
    predicted=700.829365, expected=687.790000
    predicted=708.076860, expected=591.640000
    predicted=624.337949, expected=660.250000
    predicted=620.648321, expected=607.670000
    predicted=619.413656, expected=550.460000
    predicted=606.490879, expected=662.460000
    predicted=721.581860, expected=684.020000
    predicted=619.168748, expected=682.770000
    predicted=675.410278, expected=598.220000
    predicted=605.086540, expected=552.340000
    predicted=538.288999, expected=579.040000
    predicted=620.404987, expected=543.010000
    predicted=584.450156, expected=591.770000
    predicted=653.356592, expected=679.790000
    predicted=664.771128, expected=697.560000
    predicted=622.408349, expected=704.930000
    predicted=662.315463, expected=702.200000
    predicted=634.265183, expected=634.040000
    predicted=591.961533, expected=586.090000
    predicted=622.945712, expected=701.420000
    predicted=725.446515, expected=720.760000
    predicted=697.181256, expected=727.080000
    predicted=723.743888, expected=729.710000
    predicted=706.743034, expected=715.880000
    predicted=642.633299, expected=629.650000
    predicted=642.973063, expected=570.680000
    predicted=632.597802, expected=673.830000
    predicted=720.465921, expected=696.120000
    predicted=695.419240, expected=698.470000
    predicted=713.428192, expected=705.070000
    predicted=692.568240, expected=698.820000
    predicted=629.210784, expected=628.110000
    predicted=631.719421, expected=569.640000
    predicted=620.835155, expected=629.050000
    predicted=674.357637, expected=545.480000
    predicted=583.254377, expected=650.580000
    predicted=708.190831, expected=691.320000
    predicted=671.991063, expected=689.930000
    predicted=619.563160, expected=610.150000
    predicted=625.665467, expected=546.010000
    predicted=531.072971, expected=662.250000
    predicted=679.938050, expected=688.570000
    predicted=672.596267, expected=678.880000
    predicted=687.059674, expected=684.900000
    predicted=675.922831, expected=685.180000
    predicted=610.504561, expected=613.860000
    predicted=616.071912, expected=563.560000
    predicted=617.655545, expected=675.760000
    predicted=702.748304, expected=680.750000
    predicted=662.502107, expected=688.990000
    predicted=696.828342, expected=684.770000
    predicted=670.439789, expected=681.780000
    predicted=615.661436, expected=603.370000
    predicted=619.350859, expected=545.590000
    predicted=599.782966, expected=659.410000
    predicted=699.939804, expected=683.280000
    predicted=667.057934, expected=680.370000
    predicted=686.374504, expected=684.840000
    predicted=670.683204, expected=681.970000
    predicted=608.291612, expected=603.790000
    predicted=609.061358, expected=548.760000
    predicted=605.628429, expected=655.380000
    predicted=690.968238, expected=688.760000
    predicted=673.008735, expected=697.250000
    predicted=697.281628, expected=708.990000
    predicted=683.931613, expected=711.810000
    predicted=629.140642, expected=631.500000
    predicted=621.930822, expected=566.080000
    predicted=615.255444, expected=686.420000
    predicted=719.345963, expected=721.950000
    predicted=699.862126, expected=736.790000
    predicted=733.373452, expected=724.440000
    predicted=701.982461, expected=704.110000
    predicted=628.796645, expected=622.580000
    predicted=632.349373, expected=573.760000
    predicted=633.617550, expected=698.550000
    predicted=743.501135, expected=699.800000
    predicted=690.198237, expected=701.160000
    predicted=712.924687, expected=704.650000
    predicted=688.746497, expected=717.990000
    predicted=640.616639, expected=636.540000
    predicted=645.661136, expected=584.690000
    predicted=633.998722, expected=705.140000
    predicted=732.287872, expected=719.630000
    predicted=691.199736, expected=717.550000
    predicted=725.604554, expected=723.740000
    predicted=706.955119, expected=713.130000
    predicted=639.255645, expected=645.550000
    predicted=657.043493, expected=592.990000
    predicted=645.659571, expected=735.000000
    predicted=758.441137, expected=778.170000
    predicted=740.668120, expected=795.170000
    predicted=766.663853, expected=795.190000
    predicted=750.960486, expected=758.450000
    predicted=664.273893, expected=664.760000
    predicted=676.241068, expected=593.620000
    predicted=666.559366, expected=692.470000
    predicted=759.041794, expected=722.220000
    predicted=742.828332, expected=734.020000
    predicted=752.832222, expected=726.830000
    predicted=717.726592, expected=712.190000
    predicted=648.193940, expected=644.770000
    predicted=650.393258, expected=585.880000
    predicted=638.045487, expected=713.170000
    predicted=752.488818, expected=733.450000
    predicted=714.175155, expected=733.650000
    predicted=729.581342, expected=735.470000
    predicted=717.851545, expected=751.910000
    predicted=667.340629, expected=655.850000
    predicted=656.803143, expected=584.030000
    predicted=645.916824, expected=707.700000
    predicted=750.934599, expected=748.220000
    predicted=723.244035, expected=764.920000
    predicted=768.247932, expected=769.600000
    predicted=742.761233, expected=760.170000
    predicted=668.575874, expected=670.450000
    predicted=665.754264, expected=607.950000
    predicted=664.283658, expected=727.830000
    predicted=771.377733, expected=739.750000
    predicted=732.449596, expected=733.900000
    predicted=752.875770, expected=745.450000
    predicted=736.891003, expected=729.380000
    predicted=656.466611, expected=645.850000
    predicted=664.582023, expected=585.650000
    predicted=651.392991, expected=707.200000
    predicted=744.859326, expected=726.260000
    predicted=717.162575, expected=744.720000
    predicted=749.134591, expected=741.620000
    predicted=718.351664, expected=725.930000
    predicted=647.685548, expected=642.820000
    predicted=654.897950, expected=575.760000
    predicted=633.663681, expected=665.790000
    predicted=722.607142, expected=684.240000
    predicted=694.974497, expected=706.480000
    predicted=725.192189, expected=735.890000
    predicted=717.814800, expected=747.230000
    predicted=661.707356, expected=675.250000
    predicted=655.837687, expected=594.020000
    predicted=625.027551, expected=681.560000
    predicted=714.408497, expected=690.680000
    predicted=691.403699, expected=600.180000
    predicted=649.439779, expected=681.680000
    predicted=726.100747, expected=705.860000
    predicted=638.978279, expected=655.980000
    predicted=646.619642, expected=621.010000
    predicted=671.351576, expected=745.170000
    predicted=700.912053, expected=769.850000
    predicted=713.282309, expected=772.220000
    predicted=748.472934, expected=755.000000
    predicted=726.284818, expected=734.980000
    predicted=668.640110, expected=656.420000
    predicted=677.680697, expected=596.530000
    predicted=665.973164, expected=725.850000
    predicted=777.418366, expected=746.740000
    predicted=733.386859, expected=751.370000
    predicted=751.950144, expected=733.970000
    predicted=718.170934, expected=701.960000
    predicted=635.833790, expected=622.550000
    predicted=652.046675, expected=567.690000
    predicted=640.034920, expected=684.550000
    predicted=740.686748, expected=708.590000
    predicted=706.475720, expected=718.940000
    predicted=720.291939, expected=725.350000
    predicted=700.897308, expected=726.620000
    predicted=643.530503, expected=642.440000
    predicted=641.424621, expected=583.560000
    predicted=634.697367, expected=686.980000
    predicted=725.470120, expected=688.950000
    predicted=683.369593, expected=724.250000
    predicted=741.475416, expected=712.500000
    predicted=694.366586, expected=699.500000
    predicted=634.648442, expected=622.940000
    predicted=639.655985, expected=577.290000
    predicted=618.731380, expected=696.310000
    predicted=736.083030, expected=719.810000
    predicted=701.040937, expected=719.810000
    predicted=718.230695, expected=715.790000
    predicted=693.576439, expected=710.550000
    predicted=637.782615, expected=631.520000
    predicted=640.912168, expected=572.470000
    predicted=632.934538, expected=668.900000
    predicted=715.178723, expected=683.150000
    predicted=680.671450, expected=663.910000
    predicted=686.908988, expected=660.160000
    predicted=667.461241, expected=664.430000
    predicted=613.173985, expected=587.620000
    predicted=602.914902, expected=537.340000
    predicted=601.653961, expected=644.170000
    predicted=678.964011, expected=670.370000
    predicted=649.599624, expected=674.510000
    predicted=677.107269, expected=680.520000
    predicted=659.385372, expected=673.160000
    predicted=599.747187, expected=598.160000
    predicted=600.711250, expected=549.390000
    predicted=600.359768, expected=664.860000
    predicted=694.416626, expected=676.690000
    predicted=659.986048, expected=692.610000
    predicted=695.321797, expected=677.960000
    predicted=657.209618, expected=558.440000
    predicted=517.320096, expected=557.260000
    predicted=616.881754, expected=532.390000
    predicted=583.041947, expected=640.350000
    predicted=678.181675, expected=663.090000
    predicted=678.026963, expected=669.460000
    predicted=620.857947, expected=680.870000
    predicted=643.557241, expected=677.880000
    predicted=600.168137, expected=595.530000
    predicted=596.487185, expected=541.920000
    predicted=593.146130, expected=652.120000
    predicted=683.879960, expected=667.300000
    predicted=654.713157, expected=671.030000
    predicted=682.688466, expected=661.860000
    predicted=649.610596, expected=649.780000
    predicted=587.734017, expected=580.850000
    predicted=597.247421, expected=561.980000
    predicted=609.977999, expected=666.190000
    predicted=689.775307, expected=704.870000
    predicted=676.764161, expected=697.540000
    predicted=681.902675, expected=586.010000
    predicted=575.976901, expected=620.950000
    predicted=604.071289, expected=597.710000
    predicted=609.589378, expected=557.130000
    predicted=606.882782, expected=666.440000
    predicted=725.194204, expected=702.120000
    predicted=638.254028, expected=722.830000
    predicted=681.305426, expected=719.630000
    predicted=681.183637, expected=701.640000
    predicted=624.505695, expected=625.690000
    predicted=627.074560, expected=585.070000
    predicted=632.590204, expected=707.690000
    predicted=740.351123, expected=719.680000
    predicted=702.305475, expected=640.960000
    predicted=660.378272, expected=693.000000
    predicted=701.355106, expected=697.430000
    predicted=625.417692, expected=623.660000
    predicted=637.026468, expected=573.000000
    predicted=651.145588, expected=691.510000
    predicted=690.406489, expected=712.600000
    predicted=685.700225, expected=715.530000
    predicted=714.849797, expected=716.920000
    predicted=695.812683, expected=711.520000
    predicted=635.752523, expected=630.520000
    predicted=638.696276, expected=580.750000
    predicted=636.770530, expected=703.160000
    predicted=736.089837, expected=734.970000
    predicted=711.185952, expected=759.230000
    predicted=750.038078, expected=761.650000
    predicted=722.465843, expected=766.610000
    predicted=673.386613, expected=694.180000
    predicted=680.969314, expected=654.550000
    predicted=686.764732, expected=763.740000
    predicted=786.670626, expected=776.330000
    predicted=751.346768, expected=771.770000
    predicted=776.852164, expected=681.190000
    predicted=685.786473, expected=712.510000
    predicted=689.896943, expected=644.010000
    predicted=673.999427, expected=631.810000
    predicted=692.628385, expected=771.050000
    predicted=814.969923, expected=794.750000
    predicted=723.106362, expected=799.940000
    predicted=772.975375, expected=794.570000
    predicted=743.683417, expected=778.580000
    predicted=695.348715, expected=675.710000
    predicted=695.290867, expected=622.110000
    predicted=696.249264, expected=728.510000
    predicted=783.577179, expected=746.730000
    predicted=749.958500, expected=743.070000
    predicted=768.200260, expected=727.480000
    predicted=720.892397, expected=696.360000
    predicted=646.479202, expected=621.630000
    predicted=653.171373, expected=580.700000
    predicted=651.098856, expected=585.390000
    predicted=656.422165, expected=519.240000
    predicted=591.385171, expected=607.490000
    predicted=678.089951, expected=657.510000
    predicted=646.472270, expected=659.560000
    predicted=615.734105, expected=622.760000
    predicted=618.333964, expected=586.290000
    predicted=546.598653, expected=617.170000
    Test RMSE: 44.774
    


![png](output_60_1.png)



```python

```

# Grid search ARIMA parameters for time series


```python
# grid search ARIMA parameters for time series
import warnings
from math import sqrt
from pandas import Series
from statsmodels.tsa.arima_model import ARIMA
from sklearn.metrics import mean_squared_error

# evaluate an ARIMA model for a given order (p,d,q)
def evaluate_arima_model(X, arima_order):
	# prepare training dataset
	train_size = int(len(X) * 0.95)
	train, test = X[0:train_size], X[train_size:]
	history = [x for x in train]
	# make predictions
	predictions = list()
	for t in range(len(test)):
		model = ARIMA(history, order=arima_order)
		model_fit = model.fit(disp=0)
		yhat = model_fit.forecast()[0]
		predictions.append(yhat)
		history.append(test[t])
	# calculate out of sample error
	rmse = sqrt(mean_squared_error(test, predictions))
	return rmse

# evaluate combinations of p, d and q values for an ARIMA model
def evaluate_models(dataset, p_values, d_values, q_values):
	dataset = dataset.astype('float32')
	best_score, best_cfg = float("inf"), None
	for p in p_values:
		for d in d_values:
			for q in q_values:
				order = (p,d,q)
				try:
					rmse = evaluate_arima_model(dataset, order)
					if rmse < best_score:
						best_score, best_cfg = rmse, order
					print('ARIMA%s RMSE=%.3f' % (order,rmse))
				except:
					continue
	print('Best ARIMA%s RMSE=%.3f' % (best_cfg, best_score))

# load dataset
series = Series.from_csv('Energydata_spain.csv', header=0)
# evaluate parameters
p_values = [1, 2, 4, 6, 7, 8, 10]
d_values = range(0, 3)
q_values = range(0, 3)
warnings.filterwarnings("ignore")
evaluate_models(series.values, p_values, d_values, q_values)
```

    ARIMA(1, 0, 0) RMSE=52.761
    ARIMA(1, 0, 1) RMSE=50.081
    ARIMA(1, 0, 2) RMSE=48.952
    ARIMA(1, 1, 0) RMSE=58.850
    ARIMA(1, 1, 1) RMSE=52.563
    ARIMA(1, 1, 2) RMSE=49.132
    ARIMA(1, 2, 0) RMSE=78.301
    ARIMA(1, 2, 1) RMSE=58.876
    ARIMA(2, 0, 0) RMSE=50.748
    ARIMA(2, 0, 1) RMSE=49.139
    ARIMA(2, 0, 2) RMSE=48.898
    ARIMA(2, 1, 0) RMSE=55.013
    ARIMA(2, 1, 1) RMSE=48.850
    ARIMA(2, 1, 2) RMSE=48.667
    ARIMA(2, 2, 0) RMSE=69.875
    ARIMA(2, 2, 1) RMSE=55.033
    ARIMA(4, 0, 0) RMSE=50.357
    ARIMA(4, 0, 1) RMSE=48.542
    ARIMA(4, 1, 0) RMSE=52.235
    ARIMA(4, 1, 1) RMSE=45.983
    ARIMA(4, 2, 0) RMSE=68.255
    ARIMA(4, 2, 1) RMSE=52.252
    ARIMA(4, 2, 2) RMSE=52.674
    ARIMA(6, 0, 0) RMSE=42.841
    ARIMA(6, 0, 1) RMSE=41.111
    ARIMA(6, 0, 2) RMSE=37.152
    ARIMA(6, 1, 0) RMSE=37.708
    ARIMA(6, 1, 1) RMSE=33.084
    ARIMA(6, 1, 2) RMSE=32.286
    


```python
ARIMA(6, 1, 2) has lowest RMSE (32.286)
```

The above grid search prints the ARIMA parameters and root mean squared error for each configuration successfully evaluated. The mean best parameters are reported as ARIMA(6,1,2) with a root mean squared error of 32.286.
